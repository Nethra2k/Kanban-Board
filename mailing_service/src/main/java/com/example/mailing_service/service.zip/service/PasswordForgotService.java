package com.example.mailing_service.service;

import com.example.mailing_service.dto.KanbanUser;
import com.example.mailing_service.proxy.UserCredentialProxy;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class PasswordForgotService {
    @Autowired
    private JavaMailSender javaMailSender;
    @Autowired
    private UserCredentialProxy userCredentialProxy;


    @RabbitListener(queues = "fmail-queue")
    public void sendForgotMail(String email) {
        String[] e=email.split("\"");
        String emailId=e[1];
//        System.out.println(e[1]);
        KanbanUser kanbanUser=userCredentialProxy.getUserById(emailId);
//        System.out.println(kanbanUser.getEmail());
//        System.out.println(kanbanUser.getPassword());
//        String body="Hello, we have received a request for you password of "+kanbanUser.getEmail()+"\n"+"Dont Worry."+"Your password is "+kanbanUser.getPassword();

        SimpleMailMessage message=new SimpleMailMessage();
        message.setFrom("letreroapp@gmail.com");
        message.setTo(kanbanUser.getEmail());
        String body="Dear User"+"\n"
                +"\n"+kanbanUser.getEmail()
                +"\n"
                +"We have received a request for your password"+"\n"
                +"{ Your password is "+kanbanUser.getPassword()+" }"+"\n"
                +"\n"+"\n"+"\n"+"\n"
                +"Regards" +"\n"
                +"Team Letrero"  +"\n";

        message.setText(body);
        String subject="Regarding your request for password";
        message.setSubject(subject);
        javaMailSender.send(message);
        System.out.println("mail sent successfully");
    }
}